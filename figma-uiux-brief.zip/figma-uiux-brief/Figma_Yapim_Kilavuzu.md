# Figma Yapım Kılavuzu — "BrewCup" Kahve Dükkanı Sipariş Uygulaması

> ⚠️ **Önemli not:** Bu kılavuz, Figma yönergesinde istenen 3 ekranı (Login,
> Home, Detail) **sizin Figma'da hızlıca oluşturabilmeniz için** hazırlanmış
> tam bir tasarım spesifikasyonudur. Figma bir masaüstü/web tasarım aracı
> olduğu için bu dosyayı doğrudan Figma'da oluşturamıyorum — ancak aşağıdaki
> renk kodları, tipografi, layout ve bileşen tanımlarını birebir uygularsanız
> yönergenin tüm gereksinimlerini (Auto Layout, Component, Variant) karşılayan
> bir tasarım ortaya çıkar. Aşağıdaki her ölçü Figma'ya doğrudan girilebilir.

## Konsept
**Ürün fikri:** BrewCup — mobil kahve dükkanı sipariş uygulaması.
Kullanıcı giriş yapar, ana sayfada kahve/tatlı kategorilerine göz atar, bir
ürüne dokunup detayına girer ve sepete ekler.

## 1. Tasarım Token Sistemi

### Renk Paleti (60-30-10 kuralı)
| Rol | Hex | Kullanım Oranı |
|---|---|---|
| Canvas (arka plan) | `#FBF6EF` | %60 — Zemin |
| Ink (ana metin/yüzey) | `#2B1B12` | %30 — Başlıklar, koyu yüzeyler |
| Caramel (accent/CTA) | `#C97B3D` | %10 — Butonlar, aktif durumlar |
| Sage (ikincil accent) | `#7C8F6B` | Etiket/başarı durumları için destek rengi |
| Border/Divider | `#E4D9CB` | Kart kenarlığı, ayraçlar |

Figma'da: bu 5 rengi **Local Styles → Color Styles** olarak kaydedin
(`canvas`, `ink`, `caramel`, `sage`, `border`) — bu, "belirli bir renk sistemi
düzeni" gereksinimini karşılar.

### Tipografi
- **Display / Başlıklar:** Fraunces — SemiBold / Bold (Google Fonts'tan Figma'ya eklenebilir)
- **Body / UI metni:** Inter — Regular / Medium / SemiBold

| Stil Adı | Font | Ağırlık | Boyut | Kullanım |
|---|---|---|---|---|
| Display/Logo | Fraunces | Bold | 28px | Login logo |
| Heading/Screen | Fraunces | SemiBold | 22px | Sayfa başlıkları |
| Body/Default | Inter | Regular | 14px | Açıklama metinleri |
| Body/Label | Inter | Medium | 13px | Input etiketleri, fiyatlar |
| Caption | Inter | Regular | 12px | Yardımcı metin, linkler |

### Grid ve Spacing
- Ekran genişliği referansı: **375px** (iPhone standardı)
- Kenar boşluğu (screen padding): **24px**
- Temel spacing birimi: **8px** katları (8 / 12 / 16 / 24 / 32)
- Kart köşe yuvarlaklığı: **16–20px**, buton köşe yuvarlaklığı: **12px**

## 2. Component Listesi (en az bunları oluşturun)

1. **Button** — variantlar: `Primary` (caramel zemin, cream yazı), `Secondary` (border'lı, şeffaf zemin), `Disabled` (gri, %40 opaklık)
   → *Bu component, "en az 1 component için variant" gereksinimini karşılar.*
2. **Input/Field** — variantlar: `Default`, `Password` (göz ikonlu), `Search` (büyüteç ikonlu)
3. **ProductCard** — ürün görseli alanı + isim + fiyat + "+" ekle butonu (Auto Layout, vertical)
4. **CategoryChip** — variantlar: `Selected` (caramel zemin), `Unselected` (border'lı)
5. **Banner** — promosyon şeridi (Auto Layout, horizontal, ikon + metin)

Tüm bu component'lar **Auto Layout** ile oluşturulmalı; iç padding 12–16px,
öğeler arası gap 8px olmalı.

## 3. Ekran Ekran Yapım Talimatı

### 3.1. Login Screen (Giriş Ekranı)
Frame: 375×812, arka plan `canvas`.
Auto Layout (vertical, gap 20px, padding 24px, ortalanmış):
1. Üstte 80px boşluk
2. "BrewCup" logo/wordmark — Display/Logo stili, `ink` rengi
3. Alt başlık: "Kahveni birkaç dokunuşla sipariş ver" — Body/Default, `ink` %60 opak
4. **Input/Field** (Default) — placeholder: "E-posta adresi"
5. **Input/Field** (Password) — placeholder: "Şifre"
6. **Button** (Primary) — metin: "Giriş Yap", genişlik: fill container
7. Caption link: "Şifremi unuttum" — `caramel` renginde, ortalanmış

### 3.2. Home Screen (Ana Sayfa)
Frame: 375×812, arka plan `canvas`.
Auto Layout (vertical, gap 16px, üst padding 24px, yan padding 20px):
1. Üst satır (horizontal auto layout, space-between): "Günaydın, Ada ☀️" (Heading stili) + profil ikonu (32px daire)
2. **Input/Field** (Search variant) — placeholder: "Kahve veya tatlı ara..."
3. **Banner** component — metin: "İlk siparişine %20 indirim", zemin `caramel`, köşe 20px
4. Kategori satırı (horizontal, scrollable, gap 8px): **CategoryChip** x4 → "Sıcak Kahve" (Selected), "Soğuk Kahve", "Tatlı", "Çay" (Unselected)
5. Ürün grid'i: 2 sütun, gap 12px — her hücrede **ProductCard** (en az 4 adet: Latte, Cold Brew, Cheesecake, Cappuccino)

### 3.3. Detail Screen (Detay Sayfası)
Frame: 375×812, arka plan `canvas`.
1. Üstte tam genişlik ürün görseli alanı (yükseklik 280px, alt köşeler 24px yuvarlak), sol üstte geri butonu (overlay, 36px daire, yarı saydam `ink` zemin)
2. Auto Layout (vertical, padding 24px, gap 12px):
   - Kategori etiketi (Caption, `sage` rengi, büyük harf) — örn. "SICAK KAHVE"
   - Ürün adı (Heading/Screen stili) — örn. "Karamelli Latte"
   - Fiyat (Body/Label, Bold, `caramel` rengi) — örn. "₺89.90"
   - Boyut seçici: **CategoryChip** variant'ları ile yeniden kullanım — "S / M / L"
   - Açıklama başlığı + paragraf (Body/Default, satır aralığı 1.5)
3. Alt sabit bar (Auto Layout, horizontal, space-between, padding 20px, üstte ince `border` çizgisi):
   - Adet seçici (- / sayı / +)
   - **Button** (Primary) — metin: "Sepete Ekle"

## 4. Kontrol Listesi (Teslimden Önce)
- [ ] 3 ekran da aynı renk stilleri ve font stillerini kullanıyor mu?
- [ ] Buton, input, card gibi tekrar eden öğeler component haline getirildi mi?
- [ ] En az 1 component'te variant (Button veya CategoryChip) kullanıldı mı?
- [ ] Auto Layout; buton, input, card ve ana kapsayıcı alanlarda uygulandı mı?
- [ ] Serbest/elle hizalama yapılmadı, her şey Auto Layout/Grid ile hizalandı mı?
- [ ] 3 ekranın PDF export'u alınıp `Ad_Soyad_FigmaUIUX_Tasarim.pdf` olarak kaydedildi mi?

## 5. Faydalı Kaynaklar (yönergeden)
- Renk paleti oluşturucu: 60-30-10 Color Palette Generator
- Font pairing kontrolü: fontpair.co, typepeek.com
- Component/ikon kütüphanesi: yönergedeki Figma Community linkleri
