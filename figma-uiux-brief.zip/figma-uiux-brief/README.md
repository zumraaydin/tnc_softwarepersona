# Figma UI/UX & Web Tasarımı — BrewCup

## Önemli Not
Figma; kod yazılarak değil, doğrudan Figma masaüstü/web uygulaması içinde
tasarlanan bir araç olduğu için bu ekranları sizin adınıza Figma'da
oluşturamadım. Bunun yerine size iki dosya hazırladım:

## Bu Klasördeki Dosyalar
- **Figma_Yapim_Kilavuzu.md** → "BrewCup" adlı kahve dükkanı uygulaması için
  uçtan uca tasarım spesifikasyonu: renk kodları (hex), tipografi, spacing
  sistemi, component/variant listesi ve 3 ekranın (Login, Home, Detail)
  birebir yapım talimatları. Bunu açık tutup Figma'da adım adım
  uygulayabilirsiniz — muhtemelen 1-2 saat içinde bitirebileceğiniz kadar
  detaylıdır.
- **Ad_Soyad_FigmaUIUX_Aciklama.docx** → Yönergede istenen, teslim edilecek
  açıklama belgesi. Proje Tanımı, Tasarımın Amacı, Renk Seçimi, Tipografi,
  Genel Tasarım Yaklaşımı ve Figma Özelliklerinin Kullanım Amacı bölümlerini
  içerir ve kılavuzdaki tasarımla birebir tutarlıdır.

## Yapmanız Gerekenler
1. `Figma_Yapim_Kilavuzu.md` dosyasını açın, Figma'da yeni bir dosya açıp
   kılavuzdaki adımları takip ederek 3 ekranı oluşturun.
2. Renkleri **Local Styles**, fontları **Text Styles** olarak kaydedin.
3. Button, Input, ProductCard, CategoryChip, Banner öğelerini **Component**
   yapın; Button ve CategoryChip için **Variant** tanımlayın.
4. Tüm ekranları PDF olarak export edip `Ad_Soyad_FigmaUIUX_Tasarim.pdf`
   adıyla kaydedin (yönergedeki teslim formatı).
5. `Ad_Soyad_FigmaUIUX_Aciklama.docx` dosyasındaki "Ad Soyad" alanını
   güncelleyin ve dosya adını da yönergeye göre düzenleyin.

## Teslim Edilecek 2 Dosya (Yönerge Gereği)
- `Ad_Soyad_FigmaUIUX_Tasarim.pdf` (siz Figma'da oluşturup export edeceksiniz)
- `Ad_Soyad_FigmaUIUX_Aciklama.docx` (hazır — sadece isim alanını doldurun)
