/* ============================================================
   NOVASTORE E-TİCARET VERİ YÖNETİM SİSTEMİ
   Proje: Veri Tabanı ve SQL Eğitimi - Bitirme Projesi
   Açıklama: Bu script; veri tabanı/tablo oluşturma (DDL), örnek veri
   girişi (DML), raporlama sorguları (DQL/JOIN/GROUP BY), bir VIEW ve
   yedekleme (BACKUP) komutunu içerir. SQL Server (T-SQL) için yazılmıştır.
   ============================================================ */


/* ============================================================
   BÖLÜM 1: VERİ TABANI TASARIMI (LOGICAL DESIGN & DDL)
   ============================================================ */

-- Görev: NovaStoreDB adında veri tabanı oluştur
IF DB_ID('NovaStoreDB') IS NULL
BEGIN
    CREATE DATABASE NovaStoreDB;
END
GO

USE NovaStoreDB;
GO

-- Önce var olan tabloları temizle (script'in tekrar çalıştırılabilmesi için)
-- Not: Bağımlı tablolardan bağımsız olanlara doğru silinir (FK sırası).
IF OBJECT_ID('dbo.OrderDetails', 'U') IS NOT NULL DROP TABLE dbo.OrderDetails;
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.Products', 'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;
IF OBJECT_ID('dbo.Categories', 'U') IS NOT NULL DROP TABLE dbo.Categories;
GO

-- A. Tablo: Categories (Kategoriler) — Ana tablo, önce oluşturulur
CREATE TABLE Categories (
    CategoryID   INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL
);
GO

-- C. Tablo: Customers (Müşteriler) — Ana tablo, önce oluşturulur
CREATE TABLE Customers (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    FullName   VARCHAR(50) NOT NULL,
    City       VARCHAR(20),
    Email      VARCHAR(100) NOT NULL UNIQUE
);
GO

-- B. Tablo: Products (Ürünler) — Categories'e bağımlı (FK)
CREATE TABLE Products (
    ProductID   INT IDENTITY(1,1) PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    Price       DECIMAL(10,2) NOT NULL,
    Stock       INT NOT NULL DEFAULT 0,
    CategoryID  INT NOT NULL,
    CONSTRAINT FK_Products_Categories
        FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);
GO

-- D. Tablo: Orders (Siparişler) — Customers'a bağımlı (FK)
CREATE TABLE Orders (
    OrderID      INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID   INT NOT NULL,
    OrderDate    DATETIME NOT NULL DEFAULT GETDATE(),
    TotalAmount  DECIMAL(10,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Orders_Customers
        FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);
GO

-- E. Tablo: OrderDetails (Sipariş Detayları - Ara Tablo) — Orders ve Products'a bağımlı (FK)
CREATE TABLE OrderDetails (
    DetailID   INT IDENTITY(1,1) PRIMARY KEY,
    OrderID    INT NOT NULL,
    ProductID  INT NOT NULL,
    Quantity   INT NOT NULL,
    CONSTRAINT FK_OrderDetails_Orders
        FOREIGN KEY (OrderID) REFERENCES Orders(OrderID),
    CONSTRAINT FK_OrderDetails_Products
        FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);
GO


/* ============================================================
   BÖLÜM 2: VERİ GİRİŞİ (DML - INSERT)
   ============================================================ */

-- Görev 1: 5 adet Kategori ekle
INSERT INTO Categories (CategoryName) VALUES
('Elektronik'),
('Giyim'),
('Kitap'),
('Kozmetik'),
('Ev ve Yaşam');
GO

-- Görev 2: Her kategoriye ait toplam 10-12 ürün ekle
INSERT INTO Products (ProductName, Price, Stock, CategoryID) VALUES
('Kablosuz Kulaklık',      1299.90, 45, 1),
('Akıllı Saat',            2499.00, 30, 1),
('Taşınabilir Şarj Cihazı', 499.50, 60, 1),
('Erkek Kışlık Mont',      899.00, 25, 2),
('Kadın Spor Ayakkabı',    749.90, 40, 2),
('Unisex Sırt Çantası',    349.00, 55, 2),
('Uzak İhtimal - Roman',    89.90, 18, 3),
('Kişisel Gelişim Seti',   129.90, 22, 3),
('Nemlendirici Krem',      189.90, 70, 4),
('Organik Şampuan',        119.50, 65, 4),
('Aromaterapi Mum Seti',   159.00, 15, 5),
('Dekoratif Yastık Kılıfı', 99.90, 38, 5);
GO

-- Görev 3: 5-6 adet Müşteri kaydı oluştur
INSERT INTO Customers (FullName, City, Email) VALUES
('Ahmet Yılmaz',   'İstanbul', 'ahmet.yilmaz@example.com'),
('Elif Kaya',      'Ankara',   'elif.kaya@example.com'),
('Mehmet Demir',   'İzmir',    'mehmet.demir@example.com'),
('Zeynep Şahin',   'Bursa',    'zeynep.sahin@example.com'),
('Can Öztürk',     'Malatya',  'can.ozturk@example.com'),
('Selin Aydın',    'Antalya',  'selin.aydin@example.com');
GO

-- Görev 4: Farklı tarihlerde en az 8-10 sipariş ve sipariş detayları
INSERT INTO Orders (CustomerID, OrderDate, TotalAmount) VALUES
(1, '2026-05-02', 1299.90),
(2, '2026-05-04', 2499.00),
(1, '2026-05-10', 599.40),
(3, '2026-05-15', 899.00),
(4, '2026-05-20', 1099.80),
(5, '2026-06-01', 349.00),
(2, '2026-06-05', 279.40),
(6, '2026-06-08', 749.90),
(3, '2026-06-14', 218.90),
(5, '2026-06-18', 258.90);
GO

-- Sipariş Detayları (her siparişin hangi ürün(ler)den oluştuğu)
INSERT INTO OrderDetails (OrderID, ProductID, Quantity) VALUES
(1, 1, 1),                       -- Ahmet: Kablosuz Kulaklık x1
(2, 2, 1),                       -- Elif: Akıllı Saat x1
(3, 9, 1), (3, 10, 2),           -- Ahmet: Nemlendirici x1 + Şampuan x2
(4, 4, 1),                       -- Mehmet: Kışlık Mont x1
(5, 3, 1), (5, 11, 1), (5, 12, 1), -- Zeynep: Şarj Cihazı + Mum Seti + Yastık
(6, 6, 1),                       -- Can: Sırt Çantası x1
(7, 7, 1), (7, 8, 1),            -- Elif: Roman + Kişisel Gelişim Seti
(8, 5, 1),                       -- Selin: Spor Ayakkabı x1
(9, 9, 1), (9, 10, 1),           -- Mehmet: Nemlendirici + Şampuan
(10, 11, 1), (10, 12, 1);        -- Can: Mum Seti + Yastık Kılıfı
GO


/* ============================================================
   BÖLÜM 3: SORGULAMA VE ANALİZ (DQL - SELECT ve JOIN'ler)
   ============================================================ */

-- 1. Temel Listeleme:
-- Stok miktarı 20'den az olan ürünler, stoğa göre azalan sırada
SELECT ProductName, Stock
FROM Products
WHERE Stock < 20
ORDER BY Stock DESC;
GO

-- 2. Veri Birleştirme (JOIN):
-- Hangi müşteri, hangi tarihte sipariş vermiş?
SELECT
    c.FullName   AS MusteriAdi,
    c.City       AS Sehir,
    o.OrderDate  AS SiparisTarihi,
    o.TotalAmount AS ToplamTutar
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
ORDER BY o.OrderDate;
GO

-- 3. Çoklu Birleştirme ve Detay Raporu:
-- "Ahmet Yılmaz" isimli müşterinin aldığı ürünler, fiyatlar ve kategoriler
SELECT
    c.FullName     AS MusteriAdi,
    p.ProductName  AS UrunAdi,
    p.Price        AS Fiyat,
    cat.CategoryName AS Kategori
FROM Customers c
INNER JOIN Orders o        ON c.CustomerID = o.CustomerID
INNER JOIN OrderDetails od ON o.OrderID = od.OrderID
INNER JOIN Products p      ON od.ProductID = p.ProductID
INNER JOIN Categories cat  ON p.CategoryID = cat.CategoryID
WHERE c.FullName = 'Ahmet Yılmaz';
GO

-- 4. Gruplama ve Aggregate Fonksiyonlar:
-- Hangi kategoride toplam kaç ürün var?
SELECT
    cat.CategoryName AS Kategori,
    COUNT(p.ProductID) AS UrunSayisi
FROM Categories cat
LEFT JOIN Products p ON cat.CategoryID = p.CategoryID
GROUP BY cat.CategoryName
ORDER BY UrunSayisi DESC;
GO

-- 5. Ciro Analizi (Zor):
-- Her müşterinin şirkete kazandırdığı toplam ciro (çoktan aza)
SELECT
    c.FullName AS MusteriAdi,
    SUM(o.TotalAmount) AS ToplamCiro
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.FullName
ORDER BY ToplamCiro DESC;
GO

-- 6. Zaman Analizi:
-- Bugünün tarihine göre siparişlerin üzerinden kaç gün geçti?
SELECT
    o.OrderID,
    c.FullName AS MusteriAdi,
    o.OrderDate,
    DATEDIFF(DAY, o.OrderDate, GETDATE()) AS GecenGunSayisi
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
ORDER BY GecenGunSayisi DESC;
GO


/* ============================================================
   BÖLÜM 4: İLERİ SEVİYE VERİ TABANI NESNELERİ
   ============================================================ */

-- 1. VIEW Oluşturma: Müşteri Adı, Sipariş Tarihi, Ürün Adı, Adet bilgisini
-- tek bir "tablo"ymuş gibi getiren görünüm.
IF OBJECT_ID('dbo.vw_SiparisOzet', 'V') IS NOT NULL
    DROP VIEW dbo.vw_SiparisOzet;
GO

CREATE VIEW vw_SiparisOzet AS
SELECT
    c.FullName    AS MusteriAdi,
    o.OrderDate   AS SiparisTarihi,
    p.ProductName AS UrunAdi,
    od.Quantity   AS Adet
FROM Customers c
INNER JOIN Orders o        ON c.CustomerID = o.CustomerID
INNER JOIN OrderDetails od ON o.OrderID = od.OrderID
INNER JOIN Products p      ON od.ProductID = p.ProductID;
GO

-- Kullanım örneği:
-- SELECT * FROM vw_SiparisOzet ORDER BY SiparisTarihi;

-- 2. Yedekleme (Backup):
-- NovaStoreDB veri tabanının C:\Yedek\ klasörüne yedeğini alır.
-- Not: Bu komutu çalıştırmadan önce C:\Yedek\ klasörünün var olduğundan
-- ve SQL Server servis hesabının bu klasöre yazma izni olduğundan emin olun.
BACKUP DATABASE NovaStoreDB
TO DISK = 'C:\Yedek\NovaStoreDB.bak'
WITH FORMAT,
     MEDIANAME = 'NovaStoreBackup',
     NAME = 'NovaStoreDB-Tam Yedek';
GO

/* ============================================================
   SON: Script tamamlandı.
   ============================================================ */
