# NovaStore E-Ticaret Veri Yönetim Sistemi

## Bu Klasördeki Dosyalar
- **AdSoyad_NovaStore_Proje.sql** → Tüm proje kodu: tablo oluşturma (DDL), örnek
  veri girişi (DML), 6 raporlama sorgusu, VIEW ve BACKUP komutu. Yorum
  satırları (`--`) ile hangi kodun hangi göreve ait olduğu belirtilmiştir.
- **AdSoyad_NovaStore_Proje.docx** → Yönergede istenen Word raporu. Kodlar
  kod-kutusu stiliyle biçimlendirilmiştir; turuncu kesikli çerçeveli kutular
  sizin ekran görüntülerinizi ekleyeceğiniz yerlerdir.

## Yapmanız Gerekenler (Teslim Öncesi)
1. `AdSoyad_NovaStore_Proje.sql` dosyasını **SQL Server Management Studio
   (SSMS)** veya **Azure Data Studio** ile açın ve baştan sona çalıştırın
   (script tekrar çalıştırılabilir şekilde yazılmıştır — mevcut tabloları
   otomatik olarak siler ve yeniden oluşturur).
2. Her sorguyu tek tek çalıştırıp sonuç tablosunun ekran görüntüsünü alın.
3. `AdSoyad_NovaStore_Proje.docx` dosyasını açın, her bölümdeki turuncu
   kesikli kutuların yerine ilgili ekran görüntüsünü yapıştırın.
4. Tabloları oluşturduktan sonra SSMS'in **Database Diagrams** özelliğiyle
   (veya "View Dependencies") ilişkisel yapının tek bir ekran görüntüsünü alıp
   Bölüm 1'deki kutuya ekleyin.
5. Dosya adlarını kendi Ad Soyad'ınızla güncelleyin:
   - `AdSoyad_NovaStore_Proje.sql`
   - `AdSoyad_NovaStore_Proje.docx`
   - `AdSoyad_NovaStore_Proje.png` (ilişkisel yapı görseli — ayrı bir PNG
     olarak da kaydedin)

## Notlar
- Script **T-SQL (SQL Server)** için yazılmıştır; `IDENTITY`, `GETDATE()`,
  `DATEDIFF`, `BACKUP DATABASE` gibi ifadeler SQL Server'a özeldir.
- `BACKUP DATABASE` komutunu çalıştırmadan önce bilgisayarınızda `C:\Yedek\`
  klasörünün var olduğundan emin olun (yoksa oluşturun).
